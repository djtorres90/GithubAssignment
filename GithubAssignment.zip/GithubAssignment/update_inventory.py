from docx import Document
from copy import deepcopy
p=r'C:\Users\dtorr\OneDrive\Desktop\GithubAssignment\Torres_Damien AI in my day revised.docx'
d=Document(p)
for para in d.paragraphs:
 if 'eight common tools' in para.text:
  para.text=para.text.replace('eight common tools','ten common tools')
t=d.tables[0]
items=[('9','Voice assistant','Home on a phone','Recognized a spoken request to set a reminder or search for information.','Perception'),('10','Search suggestions','School on a laptop','Predicted the rest of a search query while typing a programming question.','Prediction')]
for item in items:
 row=deepcopy(t.rows[-1]._tr); t._tbl.append(row)
 for cell,text in zip(t.rows[-1].cells,item):
  para=cell.paragraphs[0]
  run=para.runs[0]
  run.text=text
  for r in list(para.runs)[1:]: r._element.getparent().remove(r._element)
d.save(p)
print('Inventory items:',len(t.rows)-1)
