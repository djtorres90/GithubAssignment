from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from pathlib import Path
out=Path(r'C:\Users\dtorr\OneDrive\Desktop\GithubAssignment\Torres_Damien AI in my day revised.docx')
d=Document(r'C:\Users\dtorr\OneDrive\Documents\Torres_Damien AI in my day assignment.docx')
s=d.sections[0]
s.top_margin=s.bottom_margin=Inches(.7)
s.left_margin=s.right_margin=Inches(.7)
for name in ['Normal','Title','Heading 1']:
 st=d.styles[name]; st.font.name='Calibri'; st.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(11)
d.styles['Normal'].paragraph_format.space_after=Pt(6)
d.styles['Title'].font.size=Pt(22)
d.styles['Heading 1'].font.size=Pt(14)
if not d.paragraphs[0].text:
 p=d.paragraphs[0]; p.style='Title'; p.add_run('AI in My Day')
d.add_paragraph('Damien Torres | Software Development')
d.add_paragraph('AI helps with everyday tasks such as typing, finding information, and choosing what to watch. The following inventory connects eight common tools to the main AI workloads they appear to perform.')
d.add_heading('Everyday AI inventory',1)
rows=[
('1','Phone autocorrect','Home and school on a phone','Suggested corrections and words while typing messages.','Prediction'),
('2','Phone face unlock','Home on a phone','Compared a face with saved facial information to unlock the phone.','Perception'),
('3','Google Maps','Community while traveling','Estimated arrival times and suggested routes based on traffic.','Prediction'),
('4','Email spam filter','Home and school on a laptop','Flagged suspicious or unwanted messages and moved them to spam.','Decision support'),
('5','YouTube recommendations','Home on a phone or laptop','Suggested videos based on viewing activity and interests.','Prediction'),
('6','Netflix recommendations','Home while streaming','Suggested shows and movies that might match viewing preferences.','Prediction'),
('7','TikTok personalized feed','Home on a phone','Selected videos that might be interesting based on interactions.','Prediction'),
('8','ChatGPT','School on a laptop','Generated explanations of programming concepts and sample code.','Generation')]
t=d.add_table(rows=1, cols=5); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
widths=[.3,1.25,1.25,2.85,1.45]
for c,w in zip(t.columns,widths): c.width=Inches(w)
for c,txt in zip(t.rows[0].cells,['#','Tool or system','Where I used it','What it did','Main workload']): c.text=txt
for row in rows:
 for c,txt in zip(t.add_row().cells,row): c.text=txt
for ri,row in enumerate(t.rows):
 for ci,c in enumerate(row.cells):
  c.width=Inches(widths[ci]); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
  pr=c._tc.get_or_add_tcPr(); borders=OxmlElement('w:tcBorders')
  for edge in ['top','left','bottom','right']:
   e=OxmlElement('w:'+edge); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'D9D9D9'); borders.append(e)
  pr.append(borders)
  sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),'E7E6E6' if ri==0 else 'FFFFFF'); pr.append(sh)
  for p in c.paragraphs:
   p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(4)
   for r in p.runs: r.font.size=Pt(10); r.bold=ri==0
  nr=OxmlElement('w:cantSplit'); row._tr.get_or_add_trPr().append(nr)
repeat=OxmlElement('w:tblHeader'); t.rows[0]._tr.get_or_add_trPr().append(repeat)
d.add_page_break()
d.add_heading('Why these workload labels fit',1)
notes=[('Phone face unlock','I labeled this perception because it recognizes patterns in an image of a face. It uses visual information to determine whether the face matches the person allowed to unlock the phone.'),('Google Maps','I labeled this prediction because it estimates how long a trip will take using traffic information. The arrival time is an estimate of a future outcome, and it can change as traffic changes.'),('Email spam filter','I labeled this decision support because it flags messages that could be unwanted or risky. Its classification helps me decide which emails to trust, but I still need to check for mistakes.'),('ChatGPT','I labeled this generation because it creates new text or code in response to a prompt. It can produce a programming example instead of only pointing me toward an existing page.')]
for label,txt in notes:
 p=d.add_paragraph(); p.add_run(label+'. ').bold=True; p.add_run(txt)
d.add_heading('Software development reflection',1)
reflection='As a software development major, the most relevant tool in my list is ChatGPT. In software development, a tool like this can explain unfamiliar programming concepts, suggest sample code, and help identify possible causes of an error. It could also help developers draft documentation or think through different ways to solve a problem. My main concern is accuracy. Code that looks correct can still contain bugs, security weaknesses, or functions that do not exist. I would need to understand the suggested code, compare it with official documentation, and test it before using it in a project. I also would avoid sharing passwords, private user data, or confidential project files. AI could support my learning, but I still need to develop the skills to explain and maintain the code myself.'
d.add_paragraph(reflection)
d.save(out)
print(out)
print('Reflection words:',len(reflection.split()))
