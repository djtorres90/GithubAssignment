from docx import Document
from docx.shared import Pt, RGBColor
from zipfile import ZipFile
from lxml import etree
src=r'C:\Users\dtorr\OneDrive\Documents\Damien Torres Ai in my day assignment.docx'
out=r'C:\Users\dtorr\OneDrive\Desktop\GithubAssignment\Damien Torres AI in my day completed.docx'
d=Document(src)
d.add_page_break()
def heading(text):
 p=d.add_paragraph()
 p.paragraph_format.keep_with_next=True
 p.paragraph_format.space_before=Pt(12)
 p.paragraph_format.space_after=Pt(6)
 r=p.add_run(text); r.bold=True; r.font.size=Pt(14); r.font.color.rgb=RGBColor(0,0,0)
heading('Why these workload labels fit')
notes=[('Phone face unlock','I labeled this perception because it recognizes patterns in an image of a face. It compares those patterns with saved facial information to determine whether the person can unlock the phone.'),('Google Maps','I labeled this prediction because it estimates arrival times using traffic information. It predicts how long a trip might take, and the estimate can change as traffic conditions change.'),('Email spam filter','I labeled this decision support because it flags messages that may be suspicious or unwanted. This helps me decide which messages to open or trust, although I still need to check for mistakes.'),('ChatGPT','I labeled this generation because it creates explanations and sample code in response to a prompt. It produces content that can help me understand a programming concept or explore a solution.')]
for label,text in notes:
 p=d.add_paragraph(); p.paragraph_format.space_after=Pt(8)
 p.add_run(label+'. ').bold=True; p.add_run(text)
heading('Software development reflection')
text='As a software development major, the most relevant tool in my list is ChatGPT. A tool like this can help explain programming concepts, suggest sample code, and identify possible reasons for an error. In the software industry, developers can also use similar tools to draft documentation or explore different approaches to a problem. My main concern is accuracy. Generated code can look correct but still contain bugs or security problems. I would need to understand the code, check it against official documentation, and test it before using it in a project. I also would avoid sharing passwords or private project information. AI could help me learn and work through problems, but I still need the skills to explain, debug, and maintain the code myself.'
d.add_paragraph(text)
d.save(out)
a=ZipFile(src); b=ZipFile(out)
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
x=etree.fromstring(a.read('word/document.xml')).find('.//w:tbl',ns)
y=etree.fromstring(b.read('word/document.xml')).find('.//w:tbl',ns)
assert etree.tostring(x,method='c14n')==etree.tostring(y,method='c14n'), 'Table changed'
print('Original table preserved exactly. Reflection word count:',len(text.split()))
print(out)
